﻿Public Class Form1
    Dim op As String
    Dim num1 As Integer
    Dim num2 As Integer
    Dim res As Integer


    Private Sub colocarNum(numero As Integer)
        If (Resultado.Text = "0") Then
            Resultado.Text = numero
        Else
            Resultado.Text = Resultado.Text & numero
        End If
    End Sub

    Private Sub Bot0_Click(sender As Object, e As EventArgs) Handles Bot0.Click
        colocarNum(0)
    End Sub

    Private Sub Bot1_Click(sender As Object, e As EventArgs) Handles Bot1.Click
        colocarNum(1)
    End Sub

    Private Sub Bot2_Click(sender As Object, e As EventArgs) Handles Bot2.Click
        colocarNum(2)
    End Sub

    Private Sub Bot3_Click(sender As Object, e As EventArgs) Handles Bot3.Click
        colocarNum(3)
    End Sub

    Private Sub Bot4_Click(sender As Object, e As EventArgs) Handles Bot4.Click
        colocarNum(4)
    End Sub

    Private Sub Bot5_Click(sender As Object, e As EventArgs) Handles Bot5.Click
        colocarNum(5)
    End Sub

    Private Sub Bot6_Click(sender As Object, e As EventArgs) Handles Bot6.Click
        colocarNum(6)
    End Sub

    Private Sub Bot7_Click(sender As Object, e As EventArgs) Handles Bot7.Click
        colocarNum(7)
    End Sub

    Private Sub Bot8_Click(sender As Object, e As EventArgs) Handles Bot8.Click
        colocarNum(8)
    End Sub

    Private Sub Bot9_Click(sender As Object, e As EventArgs) Handles Bot9.Click
        colocarNum(9)
    End Sub

    Private Sub Botsomar_Click(sender As Object, e As EventArgs) Handles Botsomar.Click
        TxtOp.Text = "+"
        op = "+"
        TxtNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub BotMultiplicar_Click(sender As Object, e As EventArgs) Handles BotMultiplicar.Click
        TxtOp.Text = "x"
        op = "x"
        TxtNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub Botsubtrair_Click(sender As Object, e As EventArgs) Handles Botsubtrair.Click
        TxtOp.Text = "-"
        op = "-"
        TxtNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub Botdividir_Click(sender As Object, e As EventArgs) Handles Botdividir.Click
        TxtOp.Text = "/"
        op = "/"
        TxtNum1.Text = Resultado.Text
        Resultado.Text = "0"
    End Sub

    Private Sub BotCalcular_Click(sender As Object, e As EventArgs) Handles BotCalcular.Click
        If op = "+" Then
            res = num1 + num2
        ElseIf op = "-" Then
            res = num1 - num2
        ElseIf op = "x" Then
            res = num1 * num2
        ElseIf op = "/" Then
            res = num1 / num2
        End If

        Resultado.Text = res
        TxtNum1.Text = ""
        op = ""
        TxtOp.Text = op
    End Sub


    Function InStr(textogeral, textoapesquisar, numero)
        If textoapesquisar.text = textogeral.text Then
            Return numero > 0
        Else
            Return 0
        End If
    End Function


    Private Sub BotBackspace_Click(sender As Object, e As EventArgs) Handles BotBackspace.Click
        Resultado.Text = Resultado.Text.Remove(Resultado.Text.Length - 1)
        If (Resultado.Text = "") Then
            Resultado.Text = ""
        End If
    End Sub

    Private Sub botClean_Click(sender As Object, e As EventArgs) Handles botClean.Click
        Resultado.Text = ""
        TxtNum1.Text = ""
        TxtOp.Text = ""
    End Sub
End Class